package br.com.lucas.organizando;

public class Usuario {
    public String nome;

    public void retornaNome(String nome) {
        this.nome = nome;
    }
}
